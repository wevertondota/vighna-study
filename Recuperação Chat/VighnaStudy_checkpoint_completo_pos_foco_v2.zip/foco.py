import time
from datetime import datetime

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QLabel,
    QPushButton,
    QFrame,
    QComboBox,
    QSpinBox,
    QLineEdit,
    QProgressBar,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QAbstractItemView,
    QMessageBox,
    QWidget,
)

from banco import (
    listar_disciplinas,
    listar_topicos,
    registrar_sessao_foco,
    listar_sessoes_foco,
    obter_resumo_foco,
    tipos_atividade_foco,
)
from jogos import JanelaPausaDesafios


def _tempo_curto(segundos):
    segundos = max(0, int(segundos or 0))
    horas, resto = divmod(segundos, 3600)
    minutos = resto // 60
    if horas:
        return f"{horas}h {minutos:02d}min"
    return f"{minutos} min"


def _relogio(segundos):
    segundos = max(0, int(round(segundos or 0)))
    horas, resto = divmod(segundos, 3600)
    minutos, segundos = divmod(resto, 60)
    if horas:
        return f"{horas:02d}:{minutos:02d}:{segundos:02d}"
    return f"{minutos:02d}:{segundos:02d}"


class JanelaModoFoco(QDialog):
    resumo_alterado = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Modo Foco — VighnaStudy")
        self.resize(1040, 760)
        self.setMinimumSize(900, 650)
        self.setWindowFlags(self.windowFlags() | Qt.WindowMinMaxButtonsHint)
        # Janela deliberadamente não modal: o cronômetro deve continuar
        # ativo enquanto o usuário navega por Questões, Revisões, Simulados
        # e pelo restante do VighnaStudy.
        self.setModal(False)
        self.setWindowModality(Qt.NonModal)
        self.setAttribute(Qt.WA_DeleteOnClose, True)

        self.sessao_ativa = False
        self.pausada = False
        self.inicio_datetime = None
        self.inicio_segmento = None
        self.acumulado = 0.0
        self.duracao_planejada = 50 * 60
        self.expiracao_aberta = False

        self.timer = QTimer(self)
        self.timer.setInterval(250)
        self.timer.timeout.connect(self.atualizar_timer)

        self.montar_interface()
        self.carregar_disciplinas()
        self.atualizar_resumo()
        self.carregar_historico()

    def montar_interface(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 18, 22, 18)
        layout.setSpacing(12)

        cabecalho = QHBoxLayout()
        textos = QVBoxLayout()
        titulo = QLabel("Modo Foco")
        titulo.setObjectName("focusTitle")
        subtitulo = QLabel(
            "Cronometre o tempo realmente dedicado ao estudo. Pausas não entram na duração efetiva."
        )
        subtitulo.setObjectName("focusSubtitle")
        subtitulo.setWordWrap(True)
        dica = QLabel(
            "Você pode deixar esta janela aberta: o cronômetro continua enquanto usa o restante do Vighna."
        )
        dica.setObjectName("focusWindowHint")
        dica.setWordWrap(True)
        textos.addWidget(titulo)
        textos.addWidget(subtitulo)
        textos.addWidget(dica)
        cabecalho.addLayout(textos, 1)

        pausa = QPushButton("Pausa & Desafios")
        pausa.setObjectName("focusPauseButton")
        pausa.clicked.connect(self.abrir_pausa)
        cabecalho.addWidget(pausa, 0, Qt.AlignTop)
        layout.addLayout(cabecalho)

        # Resumo real de tempo.
        stats = QFrame()
        stats.setObjectName("focusStatsPanel")
        stats.setMinimumHeight(74)
        stats_layout = QGridLayout(stats)
        stats_layout.setContentsMargins(14, 10, 14, 10)
        stats_layout.setHorizontalSpacing(24)
        self.stat_hoje = self._criar_stat(stats_layout, 0, "Hoje")
        self.stat_semana = self._criar_stat(stats_layout, 1, "Esta semana")
        self.stat_sessoes = self._criar_stat(stats_layout, 2, "Sessões na semana")
        self.stat_media = self._criar_stat(stats_layout, 3, "Média por sessão")
        layout.addWidget(stats)

        # Configuração.
        self.config_panel = QFrame()
        self.config_panel.setObjectName("focusConfigPanel")
        self.config_panel.setMinimumHeight(205)
        config = QVBoxLayout(self.config_panel)
        config.setContentsMargins(16, 14, 16, 14)
        config.setSpacing(10)

        sec = QLabel("Preparar sessão")
        sec.setObjectName("focusSectionTitle")
        config.addWidget(sec)

        presets = QHBoxLayout()
        presets.setSpacing(10)
        duracao_label = QLabel("Duração")
        duracao_label.setMinimumWidth(56)
        presets.addWidget(duracao_label)
        for minutos in (25, 50, 90):
            botao = QPushButton(f"{minutos} min")
            botao.setObjectName("focusPresetButton")
            botao.setMinimumSize(72, 34)
            botao.clicked.connect(lambda _=False, m=minutos: self.definir_minutos(m))
            presets.addWidget(botao)
        personalizado = QLabel("Personalizado")
        personalizado.setMinimumWidth(86)
        presets.addWidget(personalizado)
        self.minutos = QSpinBox()
        self.minutos.setRange(5, 240)
        self.minutos.setValue(50)
        self.minutos.setSuffix(" min")
        self.minutos.setFixedSize(108, 34)
        presets.addWidget(self.minutos)
        presets.addStretch(1)
        config.addLayout(presets)

        seletores = QGridLayout()
        seletores.setHorizontalSpacing(12)
        seletores.setVerticalSpacing(8)

        seletores.addWidget(QLabel("Atividade"), 0, 0)
        self.atividade = QComboBox()
        self.atividade.setMinimumHeight(34)
        self.atividade.addItems(tipos_atividade_foco())
        seletores.addWidget(self.atividade, 1, 0)

        seletores.addWidget(QLabel("Disciplina (opcional)"), 0, 1)
        self.disciplina = QComboBox()
        self.disciplina.setMinimumHeight(34)
        self.disciplina.currentIndexChanged.connect(self.carregar_topicos)
        seletores.addWidget(self.disciplina, 1, 1)

        seletores.addWidget(QLabel("Tópico (opcional)"), 0, 2)
        self.topico = QComboBox()
        self.topico.setMinimumHeight(34)
        seletores.addWidget(self.topico, 1, 2)

        seletores.setColumnStretch(0, 1)
        seletores.setColumnStretch(1, 1)
        seletores.setColumnStretch(2, 1)
        config.addLayout(seletores)

        obs_linha = QHBoxLayout()
        obs_linha.addWidget(QLabel("Observação:"))
        self.observacao = QLineEdit()
        self.observacao.setMinimumHeight(34)
        self.observacao.setPlaceholderText("Opcional — ex.: teoria antes da bateria de questões")
        obs_linha.addWidget(self.observacao, 1)
        config.addLayout(obs_linha)

        iniciar = QPushButton("Iniciar foco")
        iniciar.setObjectName("focusPrimaryButton")
        iniciar.setMinimumHeight(38)
        iniciar.clicked.connect(self.iniciar)
        config.addWidget(iniciar, 0, Qt.AlignRight)
        layout.addWidget(self.config_panel)

        # Sessão ativa.
        self.active_panel = QFrame()
        self.active_panel.setObjectName("focusActivePanel")
        ativo = QVBoxLayout(self.active_panel)
        ativo.setContentsMargins(18, 16, 18, 16)
        ativo.setSpacing(9)

        self.contexto = QLabel("Sessão de foco")
        self.contexto.setObjectName("focusContextLabel")
        self.contexto.setAlignment(Qt.AlignCenter)
        ativo.addWidget(self.contexto)

        self.relogio = QLabel("50:00")
        self.relogio.setObjectName("focusTimerValue")
        self.relogio.setAlignment(Qt.AlignCenter)
        ativo.addWidget(self.relogio)

        self.progresso = QProgressBar()
        self.progresso.setObjectName("focusProgressBar")
        self.progresso.setTextVisible(False)
        self.progresso.setRange(0, self.duracao_planejada)
        ativo.addWidget(self.progresso)

        self.status = QLabel("Pronto")
        self.status.setObjectName("focusStatusLabel")
        self.status.setAlignment(Qt.AlignCenter)
        ativo.addWidget(self.status)

        navegacao = QLabel(
            "O foco continua contando enquanto você usa o Dashboard e as demais telas do Vighna."
        )
        navegacao.setObjectName("focusWindowHint")
        navegacao.setAlignment(Qt.AlignCenter)
        navegacao.setWordWrap(True)
        ativo.addWidget(navegacao)

        acoes = QHBoxLayout()
        acoes.addStretch()
        self.pausar_btn = QPushButton("Pausar")
        self.pausar_btn.setObjectName("focusSecondaryButton")
        self.pausar_btn.clicked.connect(self.alternar_pausa)
        acoes.addWidget(self.pausar_btn)

        encerrar = QPushButton("Encerrar sessão")
        encerrar.setObjectName("focusDangerButton")
        encerrar.clicked.connect(self.encerrar_manual)
        acoes.addWidget(encerrar)
        acoes.addStretch()
        ativo.addLayout(acoes)

        self.active_panel.hide()
        layout.addWidget(self.active_panel)

        # Histórico recente.
        historico_panel = QFrame()
        historico_panel.setObjectName("focusRecentPanel")
        hist = QVBoxLayout(historico_panel)
        hist.setContentsMargins(14, 12, 14, 12)
        hist.setSpacing(8)
        hist_title = QLabel("Sessões recentes")
        hist_title.setObjectName("focusSectionTitle")
        hist.addWidget(hist_title)

        self.tabela = QTableWidget(0, 5)
        self.tabela.setHorizontalHeaderLabels(
            ["Data", "Atividade", "Conteúdo", "Tempo real", "Estado"]
        )
        self.tabela.verticalHeader().setVisible(False)
        self.tabela.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tabela.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.tabela.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.tabela.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.tabela.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.tabela.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeToContents)
        self.tabela.setMinimumHeight(190)
        hist.addWidget(self.tabela)
        layout.addWidget(historico_panel, 1)

    def _criar_stat(self, layout, coluna, titulo):
        box = QVBoxLayout()
        valor = QLabel("0")
        valor.setObjectName("focusStatValue")
        rotulo = QLabel(titulo)
        rotulo.setObjectName("focusStatLabel")
        box.addWidget(valor)
        box.addWidget(rotulo)
        layout.addLayout(box, 0, coluna)
        return valor

    def definir_minutos(self, minutos):
        self.minutos.setValue(int(minutos))

    def carregar_disciplinas(self):
        self.disciplina.blockSignals(True)
        self.disciplina.clear()
        self.disciplina.addItem("Livre / sem vínculo", None)
        for disciplina_id, nome in listar_disciplinas():
            self.disciplina.addItem(nome, int(disciplina_id))
        self.disciplina.blockSignals(False)
        self.carregar_topicos()

    def carregar_topicos(self):
        self.topico.clear()
        self.topico.addItem("Sem tópico específico", None)
        disciplina_id = self.disciplina.currentData()
        if disciplina_id is None:
            self.topico.setEnabled(False)
            return
        self.topico.setEnabled(True)
        nome_disciplina = self.disciplina.currentText()
        for linha in listar_topicos(nome_disciplina):
            self.topico.addItem(str(linha[1]), int(linha[0]))

    def atualizar_resumo(self):
        resumo = obter_resumo_foco()
        self.stat_hoje.setText(_tempo_curto(resumo["hoje_segundos"]))
        self.stat_semana.setText(_tempo_curto(resumo["semana_segundos"]))
        self.stat_sessoes.setText(str(resumo["semana_sessoes"]))
        self.stat_media.setText(_tempo_curto(resumo["media_sessao_semana"]))

    def carregar_historico(self):
        sessoes = listar_sessoes_foco(12)
        self.tabela.setRowCount(len(sessoes))
        for linha, sessao in enumerate(sessoes):
            data = str(sessao["inicio"] or "")
            try:
                data = datetime.strptime(data[:19], "%Y-%m-%d %H:%M:%S").strftime("%d/%m %H:%M")
            except Exception:
                data = data[:16]
            conteudo = sessao.get("disciplina") or "Livre"
            if sessao.get("topico"):
                conteudo += f" › {sessao['topico']}"
            valores = [
                data,
                sessao.get("tipo_atividade") or "—",
                conteudo,
                _tempo_curto(sessao.get("duracao_efetiva", 0)),
                "Concluída" if sessao.get("concluida") else "Interrompida",
            ]
            for coluna, valor in enumerate(valores):
                item = QTableWidgetItem(str(valor))
                if coluna in (3, 4):
                    item.setTextAlignment(Qt.AlignCenter)
                self.tabela.setItem(linha, coluna, item)

    def iniciar(self):
        if self.sessao_ativa:
            return
        minutos = max(5, int(self.minutos.value()))
        self.duracao_planejada = minutos * 60
        self.inicio_datetime = datetime.now()
        self.inicio_segmento = time.monotonic()
        self.acumulado = 0.0
        self.pausada = False
        self.sessao_ativa = True
        self.expiracao_aberta = False

        conteudo = self.disciplina.currentText()
        if self.disciplina.currentData() is None:
            conteudo = "Sessão livre"
        elif self.topico.currentData() is not None:
            conteudo += f" › {self.topico.currentText()}"
        self.contexto.setText(f"{self.atividade.currentText()} • {conteudo}")
        self.status.setText("Foco em andamento")
        self.pausar_btn.setText("Pausar")
        self.progresso.setRange(0, self.duracao_planejada)
        self.progresso.setValue(0)
        # Durante uma sessão, a configuração não é necessária. Ocultá-la
        # evita compressão vertical e deixa o cronômetro como elemento central.
        self.config_panel.hide()
        self.active_panel.show()
        self.timer.start()
        self.atualizar_timer()

    def tempo_decorrido(self):
        total = float(self.acumulado)
        if self.sessao_ativa and not self.pausada and self.inicio_segmento is not None:
            total += max(0.0, time.monotonic() - self.inicio_segmento)
        return total

    def alternar_pausa(self):
        if not self.sessao_ativa:
            return
        if self.pausada:
            self.pausada = False
            self.inicio_segmento = time.monotonic()
            self.pausar_btn.setText("Pausar")
            self.status.setText("Foco em andamento")
        else:
            self.acumulado = self.tempo_decorrido()
            self.inicio_segmento = None
            self.pausada = True
            self.pausar_btn.setText("Retomar")
            self.status.setText("Sessão pausada — este tempo não será contado")
        self.atualizar_timer()

    def atualizar_timer(self):
        if not self.sessao_ativa:
            return
        decorrido = self.tempo_decorrido()
        restante = max(0.0, self.duracao_planejada - decorrido)
        self.relogio.setText(_relogio(restante))
        self.progresso.setMaximum(max(1, int(self.duracao_planejada)))
        self.progresso.setValue(min(int(decorrido), int(self.duracao_planejada)))
        if restante <= 0.0 and not self.expiracao_aberta:
            self.expiracao_aberta = True
            self.acumulado = decorrido
            self.inicio_segmento = None
            self.pausada = True
            self.timer.stop()
            QTimer.singleShot(0, self.tratar_fim_planejado)

    def tratar_fim_planejado(self):
        if not self.sessao_ativa:
            return
        caixa = QMessageBox(self)
        caixa.setWindowTitle("Sessão concluída")
        caixa.setIcon(QMessageBox.Information)
        caixa.setText(
            f"Você completou {_tempo_curto(self.duracao_planejada)} de foco."
        )
        caixa.setInformativeText(
            "Você pode concluir agora, fazer uma pausa ou acrescentar 10 minutos."
        )
        b_pausa = caixa.addButton("Pausa & Desafios", QMessageBox.ButtonRole.ActionRole)
        b_mais = caixa.addButton("+10 min de foco", QMessageBox.ButtonRole.ActionRole)
        b_concluir = caixa.addButton("Concluir", QMessageBox.ButtonRole.AcceptRole)
        caixa.setDefaultButton(b_concluir)
        caixa.exec()
        clicado = caixa.clickedButton()

        if clicado is b_mais:
            self.duracao_planejada += 10 * 60
            self.pausada = False
            self.inicio_segmento = time.monotonic()
            self.expiracao_aberta = False
            self.status.setText("Foco estendido por mais 10 minutos")
            self.pausar_btn.setText("Pausar")
            self.timer.start()
            self.atualizar_timer()
            return

        self.finalizar(concluida=True)
        if clicado is b_pausa:
            JanelaPausaDesafios(self).exec()

    def encerrar_manual(self):
        if not self.sessao_ativa:
            return
        if not self.pausada:
            self.acumulado = self.tempo_decorrido()
            self.inicio_segmento = None
            self.pausada = True

        decorrido = int(round(self.acumulado))
        caixa = QMessageBox(self)
        caixa.setWindowTitle("Encerrar sessão")
        caixa.setIcon(QMessageBox.Question)
        caixa.setText(f"Tempo efetivo registrado até agora: {_tempo_curto(decorrido)}.")
        caixa.setInformativeText(
            "Marcar esta sessão como concluída? Se escolher 'Interrompida', o tempo continua sendo registrado, mas o estado ficará como interrompido."
        )
        concluida_btn = caixa.addButton("Concluída", QMessageBox.ButtonRole.AcceptRole)
        interrompida_btn = caixa.addButton("Interrompida", QMessageBox.ButtonRole.DestructiveRole)
        cancelar_btn = caixa.addButton("Cancelar", QMessageBox.ButtonRole.RejectRole)
        caixa.exec()
        clicado = caixa.clickedButton()
        if clicado is cancelar_btn:
            self.inicio_segmento = time.monotonic()
            self.pausada = False
            self.pausar_btn.setText("Pausar")
            self.status.setText("Foco em andamento")
            return
        self.finalizar(concluida=(clicado is concluida_btn))

    def finalizar(self, concluida):
        if not self.sessao_ativa:
            return
        if not self.pausada:
            self.acumulado = self.tempo_decorrido()
        self.timer.stop()
        efetiva = max(0, int(round(self.acumulado)))
        fim = datetime.now()

        if efetiva > 0:
            registrar_sessao_foco(
                inicio=self.inicio_datetime.strftime("%Y-%m-%d %H:%M:%S"),
                fim=fim.strftime("%Y-%m-%d %H:%M:%S"),
                duracao_planejada=int(self.duracao_planejada),
                duracao_efetiva=efetiva,
                disciplina_id=self.disciplina.currentData(),
                topico_id=self.topico.currentData(),
                tipo_atividade=self.atividade.currentText(),
                concluida=bool(concluida),
                observacao=self.observacao.text(),
                disciplina_nome=(
                    self.disciplina.currentText()
                    if self.disciplina.currentData() is not None else None
                ),
                topico_nome=(
                    self.topico.currentText()
                    if self.topico.currentData() is not None else None
                ),
            )

        self.sessao_ativa = False
        self.pausada = False
        self.inicio_segmento = None
        self.acumulado = 0.0
        self.expiracao_aberta = False
        self.active_panel.hide()
        self.config_panel.setEnabled(True)
        self.config_panel.show()
        self.status.setText("Pronto")
        self.atualizar_resumo()
        self.carregar_historico()
        self.resumo_alterado.emit()

    def abrir_pausa(self):
        if self.sessao_ativa and not self.pausada:
            self.alternar_pausa()
        JanelaPausaDesafios(self).exec()

    def closeEvent(self, event):
        if not self.sessao_ativa:
            event.accept()
            return
        resposta = QMessageBox.question(
            self,
            "Sessão em andamento",
            "Encerrar a janela e registrar o tempo de foco atual como sessão interrompida?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if resposta == QMessageBox.Yes:
            self.finalizar(concluida=False)
            event.accept()
        else:
            event.ignore()
