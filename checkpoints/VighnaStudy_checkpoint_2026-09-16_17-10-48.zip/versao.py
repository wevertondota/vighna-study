"""Metadados centrais de versão do VighnaStudy."""

VIGHNA_VERSION = "0.22.6"
VIGHNA_BUILD = "recuperacao-banco-segura-v1"
VIGHNA_SCHEMA = 14
