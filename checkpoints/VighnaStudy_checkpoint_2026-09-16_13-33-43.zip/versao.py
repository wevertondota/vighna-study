"""Metadados centrais de versão do VighnaStudy."""

VIGHNA_VERSION = "0.15.0"
VIGHNA_BUILD = "topicos-desligados-questoes-desativadas-v1"
VIGHNA_SCHEMA = 12
