"""Metadados centrais de versão do VighnaStudy."""

VIGHNA_VERSION = "0.23.1"
VIGHNA_BUILD = "dashboard-compacto-atalhos-v1"
VIGHNA_SCHEMA = 14
