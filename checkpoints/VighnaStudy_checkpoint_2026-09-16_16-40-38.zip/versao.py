"""Metadados centrais de versão do VighnaStudy."""

VIGHNA_VERSION = "0.22.2"
VIGHNA_BUILD = "recomendado-hoje-v2"
VIGHNA_SCHEMA = 14
