"""Metadados centrais de versão do VighnaStudy."""

VIGHNA_VERSION = "0.22.7"
VIGHNA_BUILD = "comecar-bateria-inteligente-v2"
VIGHNA_SCHEMA = 14
