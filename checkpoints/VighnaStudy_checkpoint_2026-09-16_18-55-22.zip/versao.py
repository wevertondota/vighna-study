"""Metadados centrais de versão do VighnaStudy."""

VIGHNA_VERSION = "0.23.3"
VIGHNA_BUILD = "central-questoes-administrativa-v1"
VIGHNA_SCHEMA = 14
