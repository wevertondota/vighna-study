"""Metadados centrais de versão do VighnaStudy."""

VIGHNA_VERSION = "0.23.2"
VIGHNA_BUILD = "perfil-central-harmonia-dashboard-v1"
VIGHNA_SCHEMA = 14
