"""Metadados centrais de versão do VighnaStudy."""

VIGHNA_VERSION = "0.17.0"
VIGHNA_BUILD = "reorganizacao-desativados-v1"
VIGHNA_SCHEMA = 13
