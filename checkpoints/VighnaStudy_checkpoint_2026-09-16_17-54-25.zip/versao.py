"""Metadados centrais de versão do VighnaStudy."""

VIGHNA_VERSION = "0.23.0"
VIGHNA_BUILD = "estrategias-estudo-prioritarias-v1"
VIGHNA_SCHEMA = 14
