"""Metadados centrais de versão do VighnaStudy."""

VIGHNA_VERSION = "0.22.0"
VIGHNA_BUILD = "algoritmo-lixeira-topicos-v1"
VIGHNA_SCHEMA = 14
