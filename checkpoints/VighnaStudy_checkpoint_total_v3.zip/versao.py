"""Metadados centrais de versão do VighnaStudy."""

VIGHNA_VERSION = "0.18.0"
VIGHNA_BUILD = "checkpoint-total-v3"
VIGHNA_SCHEMA = 13
